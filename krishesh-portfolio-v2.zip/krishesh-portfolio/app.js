(function(){
'use strict';
/* All editable text lives here */
var CONFIG={
  name:'Krishesh Pandey',first:'Krishesh',availShort:'Student · Technology Enthusiast',
  roles:['Tech Enthusiast','AI Explorer','Web & UI/UX','Graphic Designer','Photo & Video Editor'],
  tz:'Asia/Kolkata',email:'krisheshpandey210@gmail.com',
  ctaText:'Learning today, innovating tomorrow. Have an idea, a project or a collaboration in mind? Write to me and let’s build something meaningful.',
  skills:[
    {key:'ai',plate:'AI<br>EXPLORER',title:'Artificial Intelligence',cap:'EXPERIMENTING WITH AI-POWERED CREATIVE TOOLS',color:'#1F2E4D',intro:'I explore AI tools and emerging technologies, turning curiosity into creative experiments and useful ideas.',tools:['AI tools','Research','Prompting']},
    {key:'web',plate:'WEB<br>&amp; UI/UX',title:'Web &amp; UI/UX Design',cap:'WEBSITES THAT FEEL HANDCRAFTED',color:'#4A3340',intro:'I enjoy designing and building websites and interfaces that are clear, smooth and a little magical.',tools:['HTML','CSS','JavaScript','UI/UX']},
    {key:'graphic',plate:'GRAPHIC<br>DESIGNER',title:'Graphic Design',cap:'POSTERS, VISUALS, DIGITAL ART',color:'#7C8B6F',intro:'Visual ideas turned into clean posters and digital designs with a strong point of view.',tools:['Design','Layout','Typography']},
    {key:'media',plate:'PHOTO &amp;<br>VIDEO',title:'Photo &amp; Video Editing',cap:'STORIES TOLD THROUGH MEDIA',color:'#A9522B',intro:'Editing photos and videos to shape moments into digital content people remember.',tools:['Editing','Colour','Storytelling']},
    {key:'science',plate:'SCIENCE &amp;<br>INNOVATION',title:'Science &amp; Innovation',cap:'PHYSICS, CHEMISTRY, BIOLOGY, TECH',color:'#1E1B1B',intro:'A State Level 2nd position in the TCS Rural IT Quiz 2026 and a love for science that drives my projects.',tools:['Physics','Chemistry','Biology','Computer Technology']}
  ]
};
var $=function(id){return document.getElementById(id)};
var reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
var wait=function(ms){return new Promise(function(r){setTimeout(r,ms)})};

/* text from CONFIG */
document.title=CONFIG.name+' — Portfolio';
$('lname').textContent=CONFIG.name;
$('availShort').textContent=CONFIG.availShort;
$('ctaText').textContent=CONFIG.ctaText;
$('mail').href='mailto:'+CONFIG.email;
$('foot').textContent='© '+new Date().getFullYear()+' '+CONFIG.name+'. Designed and built by '+CONFIG.first+'.';
var words=function(t,cls){return t.split(' ').map(function(w,i){return '<span class="w"><span style="transition-delay:'+(i*80)+'ms">'+w+'</span></span>'}).join(' ')};
$('h1').innerHTML=words('Hi, I’m '+CONFIG.first+'.')+'<br><span class="soft">'+words('I am a')+'</span>';

/* clock aligned to the minute */
var fmt=new Intl.DateTimeFormat('en-US',{hour:'numeric',minute:'2-digit',hour12:true,timeZone:CONFIG.tz});
function tick(){$('clock').textContent=fmt.format(new Date()).replace(' ','').toLowerCase();setTimeout(tick,60000-Date.now()%60000+50)}
tick();

/* theme */
var dark=document.documentElement.dataset.theme==='dark';
function applyTheme(){
  document.documentElement.dataset.theme=dark?'dark':'light';
  $('hit').setAttribute('aria-pressed',dark);
  document.querySelector('meta[name=theme-color]').content=dark?'#1A1818':'#E8E4E0';
  try{localStorage.setItem('folio-theme',dark?'dark':'light')}catch(e){}
  window.dispatchEvent(new Event('themechange'));
}
function toggleTheme(x,y){
  dark=!dark;
  document.documentElement.style.setProperty('--tx',x+'px');
  document.documentElement.style.setProperty('--ty',y+'px');
  if(document.startViewTransition&&!reduced){document.startViewTransition(applyTheme)}else{applyTheme()}
}

/* loader */
var cols=['#1A1717'].concat(CONFIG.skills.map(function(s){return s.color})).slice(0,6);
var labels=[CONFIG.name].concat(CONFIG.skills.map(function(s){return s.title}));
var stack=$('stack');
cols.forEach(function(c,i){
  var d=document.createElement('div');d.className='cap';d.innerHTML=labels[i];
  d.style.background='linear-gradient(180deg,'+c+',color-mix(in srgb,'+c+' 70%,#000))';
  d.style.setProperty('--d',(i*0.5)+'s');d.style.setProperty('--o',((cols.length-1-i)*60)+'ms');d.style.zIndex=i+1;stack.appendChild(d);
});
var cols3=[];
[0,1,2].forEach(function(){
  var c=document.createElement('div');c.className='col';var inner=document.createElement('div');
  for(var n=0;n<10;n++){var s=document.createElement('span');s.textContent=n;inner.appendChild(s)}
  c.appendChild(inner);$('num').appendChild(c);cols3.push(inner);
});
function setNum(v){var s=String(v).padStart(3,'0');cols3.forEach(function(el,i){el.style.transform='translateY(-'+s[i]+'em)'})}
setNum(0);
async function runLoader(){
  var caps=stack.children;
  for(var i=0;i<caps.length;i++){caps[i].classList.add('in');await wait(70)}
  var t0=performance.now(),min=reduced?600:2200,ready=false;
  var fontsReady=(document.fonts&&document.fonts.ready)||Promise.resolve();
  Promise.race([fontsReady,wait(4000)]).then(function(){ready=true});
  await new Promise(function(res){
    (function loop(){
      var p=Math.min((performance.now()-t0)/min,1);
      var eased=1-Math.pow(1-p,2.2);
      var v=Math.floor(eased*100);if(v>99&&!(ready&&p>=1))v=99;if(ready&&p>=1)v=100;
      setNum(v);$('bar').style.transform='scaleX('+v/100+')';
      if(v>=100)res();else requestAnimationFrame(loop);
    })();
  });
  await wait(250);
  $('loader').classList.add('out');
  await wait(700);
  document.body.classList.add('go');
  document.querySelector('.hero').classList.add('go');
  ropeIn();
  await wait(400);
  $('loader').remove();
}

/* flip notebook */
var roles=CONFIG.roles,ri=0,flipping=false,flips=0,timer=null;
var rings=$('rings');for(var k=0;k<12;k++)rings.appendChild(document.createElement('i'));
$('nb').setAttribute('aria-label','Roles: '+roles.join(', '));
function pad(n){return String(n).padStart(2,'0')}
function showRole(){
  $('topSheet').textContent=roles[ri];
  $('under').textContent=roles[(ri+1)%roles.length];
  $('cnt').textContent=pad(ri+1)+' / '+pad(roles.length);
}
function fit(){ // shrink until the longest role fits on one line
  var nb=$('nb'),size=parseFloat(getComputedStyle($('topSheet')).fontSize);
  var probe=$('topSheet'),prev=probe.textContent,longest=roles.reduce(function(a,b){return b.length>a.length?b:a});
  probe.style.fontSize='';probe.textContent=longest;
  var s=size;while(probe.scrollWidth>probe.clientWidth&&s>16){s-=2;probe.style.fontSize=s+'px';$('under').style.fontSize=s+'px'}
  probe.textContent=prev;
}
function flip(){
  if(flipping)return;flipping=true;flips++;
  var t=$('topSheet');t.classList.add('flip');
  t.addEventListener('animationend',function(){
    ri=(ri+1)%roles.length;t.classList.remove('flip');showRole();flipping=false;
  },{once:true});
}
function schedule(){
  clearInterval(timer);
  if(reduced)return;
  timer=setInterval(function(){if(!document.hidden&&flips<12)flip();else if(flips>=12)clearInterval(timer)},2800);
}
showRole();fit();schedule();
$('nb').addEventListener('click',flip);
$('nb').addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();flip()}});
$('nb').addEventListener('mouseenter',function(){clearInterval(timer)});
$('nb').addEventListener('mouseleave',function(){if(flips<12)schedule()});

/* buttons */
$('see').addEventListener('click',function(){$('doors').scrollIntoView({behavior:reduced?'auto':'smooth'})});
$('hire').addEventListener('click',function(e){hireMail(e)});
var mn=$('mnav');function menu(o){mn.classList.toggle('open',o);$('menu').classList.toggle('x',o);document.body.style.overflow=o?'hidden':''}
$('menu').addEventListener('click',function(){menu(!mn.classList.contains('open'))});
Array.prototype.forEach.call(mn.querySelectorAll('a'),function(a){a.addEventListener('click',function(e){e.preventDefault();menu(false);var t=document.querySelector(a.getAttribute('href'));if(t)setTimeout(function(){t.scrollIntoView({behavior:reduced?'auto':'smooth'})},120)})});

/* doors */
var wall=$('wall'),dotsEl=$('dots'),active=0,interacted=false;
CONFIG.skills.forEach(function(s,i){
  var b=document.createElement('button');b.className='door';b.setAttribute('aria-label','Open '+s.title.replace(/&amp;/g,'and')+' page');
  b.style.setProperty('--c',s.color);
  b.innerHTML='<div class="frame"><div class="doorway"></div><div class="leaf"><div class="plate">'+s.plate+'</div><div class="lever"></div></div></div>';
  b.addEventListener('click',function(){openDoor(i,b)});
  wall.appendChild(b);
  var d=document.createElement('button');d.setAttribute('aria-label','Door '+(i+1));
  d.addEventListener('click',function(){wall.children[i].scrollIntoView({behavior:'smooth',inline:'center',block:'nearest'})});
  dotsEl.appendChild(d);
});
function setActive(i){
  if(i===active&&$('dtt').innerHTML)return;
  active=i;var dt=$('dt');dt.classList.add('sw');
  setTimeout(function(){$('dtt').innerHTML=CONFIG.skills[i].title;$('dtc').textContent=CONFIG.skills[i].cap;dt.classList.remove('sw')},reduced?0:240);
  Array.prototype.forEach.call(dotsEl.children,function(d,n){d.classList.toggle('on',n===i)});
}
function onWall(){
  var r=wall.getBoundingClientRect(),mid=r.left+r.width/2,best=0,bd=1e9;
  Array.prototype.forEach.call(wall.children,function(d,i){
    var b=d.getBoundingClientRect(),dist=Math.abs(b.left+b.width/2-mid);
    if(dist<bd){bd=dist;best=i}
    var k=1-0.06*Math.min(1,dist/b.width);d.style.transform='scale('+k+')';d.style.opacity=dist<4?1:.9;
  });
  setActive(best);
}
wall.addEventListener('scroll',function(){requestAnimationFrame(onWall);if(!interacted&&wall.scrollLeft>8){}},{passive:true});
setActive(0);onWall();
setInterval(function(){
  if(interacted||document.hidden)return;var d=wall.children[active];d.classList.remove('breathe');void d.offsetWidth;d.classList.add('breathe');
},5000);

var busy=false,openEl=null;
async function openDoor(i,el){
  if(busy)return;busy=true;interacted=true;$('hint').style.opacity=0;
  var s=CONFIG.skills[i];openEl=el;
  $('rt').innerHTML=s.title;$('ri').textContent=s.intro;
  $('rc').innerHTML=s.tools.map(function(t){return '<span>'+t+'</span>'}).join('');renderRoom(s.key);$('room').scrollTop=0;
  el.classList.add('open');
  await wait(reduced?0:700);
  document.body.style.overflow='hidden';
  $('room').classList.add('on');
  await wait(reduced?0:900);
  $('rt').setAttribute('tabindex','-1');$('rt').focus({preventScroll:true});
  busy=false;
}
$('back').addEventListener('click',async function(){
  if(busy)return;busy=true;
  $('room').classList.remove('on');
  await wait(reduced?0:800);
  document.body.style.overflow='';
  if(openEl)openEl.classList.remove('open');
  busy=false;
});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&$('room').classList.contains('on'))$('back').click()});

/* rope: Verlet chain with a drag-able knob */
var cv=$('rope'),ctx=cv.getContext('2d'),dpr=Math.min(devicePixelRatio||1,2);
cv.width=120*dpr;cv.height=320*dpr;
var N=10,REST=innerWidth<700?118:150,SEG=REST/(N-1),AX=120-(innerWidth<700?36:56)+0,anchorY=-210;
var pts=[];for(var p=0;p<N;p++)pts.push({x:AX,y:anchorY+p*SEG,px:AX,py:anchorY+p*SEG});
var dragging=false,target={x:0,y:0},crossed=false,dstart=0,moved=0,sx=0,sy=0,ropeVisible=false,anchorOff=-200,t=0;
function ropeIn(){ropeVisible=true;var t0=performance.now();(function f(){var k=Math.min((performance.now()-t0)/900,1);anchorOff=-200*(1-(1-Math.pow(1-k,3)));if(k<1)requestAnimationFrame(f)})()}
function step(dt){
  t+=dt;pts[0].x=AX;pts[0].y=-10+anchorOff;
  for(var i=1;i<N;i++){
    var q=pts[i],vx=(q.x-q.px)*.985,vy=(q.y-q.py)*.985;q.px=q.x;q.py=q.y;
    var sway=i>N-4?Math.sin(t*1.3)*14+Math.sin(t*.7+1)*8:0;
    q.x+=vx+sway*dt*dt;q.y+=vy+2200*dt*dt;
  }
  if(dragging){var k=pts[N-1];k.x+=(target.x-k.x)*.5;k.y+=(target.y-k.y)*.5;k.px=k.x;k.py=k.y}
  for(var it=0;it<8;it++){
    for(var j=0;j<N-1;j++){
      var a=pts[j],b=pts[j+1],dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1,diff=(d-SEG)/d;
      var pinA=j===0,pinB=dragging&&j+1===N-1;
      var wa=pinA?0:pinB?1:.5,wb=pinB?0:pinA?1:.5;
      a.x+=dx*diff*wa;a.y+=dy*diff*wa;b.x-=dx*diff*wb;b.y-=dy*diff*wb;
    }
    pts[0].x=AX;pts[0].y=-10+anchorOff;
  }
}
var last=performance.now(),acc=0;
function draw(){
  var col=dark?'#CDB88F':'#BFA982';
  ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,120,320);
  if(!ropeVisible)return;
  ctx.save();ctx.shadowColor='rgba(0,0,0,.25)';ctx.shadowBlur=6;ctx.shadowOffsetX=3;ctx.shadowOffsetY=4;
  ctx.lineCap='round';ctx.lineWidth=4.5;ctx.strokeStyle=col;
  ctx.beginPath();ctx.moveTo(pts[0].x,pts[0].y);
  for(var i=1;i<N-1;i++){var mx=(pts[i].x+pts[i+1].x)/2,my=(pts[i].y+pts[i+1].y)/2;ctx.quadraticCurveTo(pts[i].x,pts[i].y,mx,my)}
  ctx.lineTo(pts[N-1].x,pts[N-1].y);ctx.stroke();ctx.restore();
  ctx.save();ctx.setLineDash([2,3]);ctx.lineWidth=4.5;ctx.strokeStyle='rgba(80,60,30,.55)';ctx.stroke();ctx.restore();
  var e=pts[N-1],f=pts[N-2],ang=Math.atan2(e.y-f.y,e.x-f.x)-Math.PI/2;
  ctx.save();ctx.translate(e.x,e.y);ctx.rotate(ang);
  var g=ctx.createLinearGradient(0,0,0,34);g.addColorStop(0,'#7A4B2A');g.addColorStop(.5,'#4B2A14');g.addColorStop(1,'#2C170A');
  ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(0,-2);ctx.bezierCurveTo(14,10,12,34,0,34);ctx.bezierCurveTo(-12,34,-14,10,0,-2);ctx.fill();
  ctx.fillStyle='rgba(255,255,255,.35)';ctx.beginPath();ctx.ellipse(-4,12,2.5,6,.2,0,7);ctx.fill();
  ctx.fillStyle='#3A3633';ctx.fillRect(-5,-4,10,4);ctx.restore();
  var h=$('hit'),rc=cv.getBoundingClientRect();
  h.style.transform='translate('+(rc.left+e.x-28)+'px,'+(rc.top+e.y+4-4)+'px)';
}
function frame(now){
  if(!document.hidden){
    acc+=Math.min((now-last)/1000,.05);
    var n=0;while(acc>=1/120&&n<4){step(1/120);acc-=1/120;n++}
    draw();
  }
  last=now;requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
var hit=$('hit');
function local(e){var r=cv.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top}}
hit.addEventListener('pointerdown',function(e){
  hit.setPointerCapture(e.pointerId);dragging=true;crossed=false;dstart=performance.now();moved=0;sx=e.clientX;sy=e.clientY;target=local(e);
});
hit.addEventListener('pointermove',function(e){
  if(!dragging)return;moved=Math.max(moved,Math.hypot(e.clientX-sx,e.clientY-sy));
  var l=local(e),maxY=-10+anchorOff+REST*1.65;
  target.x=Math.max(AX-60,Math.min(AX+60,l.x));target.y=Math.max(40,Math.min(maxY,l.y));
  var thr=innerWidth<700?56:70;
  if(!crossed&&target.y>REST-10+thr){crossed=true;if(navigator.vibrate)navigator.vibrate(8)}
});
function release(){
  if(!dragging)return;dragging=false;
  var quick=moved<6&&performance.now()-dstart<250;
  if(quick){var k=pts[N-1];k.py=k.y-14}
  if(crossed||quick){var r=hit.getBoundingClientRect();toggleTheme(r.left+r.width/2,r.top+r.height/2)}
}
hit.addEventListener('pointerup',release);
hit.addEventListener('pointercancel',function(){dragging=false});
hit.addEventListener('keydown',function(e){
  if(e.key==='Enter'||e.key===' '){e.preventDefault();var k=pts[N-1];k.py=k.y-70;var r=hit.getBoundingClientRect();toggleTheme(r.left+r.width/2,r.top+r.height/2)}
});
hit.setAttribute('aria-pressed',dark);


/* rooms content */
var ROOMS={
ai:{focus:[['Prompt thinking','How clear instructions, context and examples change what an AI gives back.'],['Creative workflows','Using AI for ideas, moodboards and first drafts — then making the result mine.'],['Study helpers','Turning tough chapters into simple explanations, quizzes and revision plans.'],['Responsible use','Fact-checking, giving credit, and remembering AI assists thinking — it doesn’t replace it.']],
steps:[['Ask','State the goal in one clear line.'],['Context','Say who it’s for and what I already know.'],['Refine','Iterate: shorter, simpler, better.'],['Verify','Cross-check facts before trusting.']],
ideas:[['AI Study Buddy','A friendly helper that turns a chapter into flashcards, doubts and a 10-minute revision plan.'],['Prompt Library','A small collection of tested prompts for notes, captions and poster ideas.'],['Idea-to-Poster Flow','A repeatable path: idea → prompt → draft → hand-polished design.']],
know:[['Did you know','The term “artificial intelligence” dates back to a 1956 workshop at Dartmouth.'],['Prompt tip','Say who the answer is for: “explain like I’m in Class 9”.'],['Habit','Always ask: how do I know this is true?'],['Fun fact','Machine learning models learn patterns from data instead of fixed rules.']],
next:['Python basics','Small ML demos','Study chatbot idea','Ethical AI']},
web:{focus:[['Semantic HTML','Structuring pages so they make sense to people, search engines and screen readers.'],['Responsive CSS','Flexbox, Grid and clamp() so one layout works on every screen.'],['Micro-interactions','Hover states, easing and tiny motion that make a page feel alive.'],['UI/UX thinking','Hierarchy, spacing and readability before decoration.']],
steps:[['Sketch','Rough layout on paper first.'],['Structure','Write clean HTML.'],['Style','Type, colour, spacing in CSS.'],['Polish','Motion, mobile, details.']],
ideas:[['Study Notes Site','Clean reading layout with dark mode for quick chapter revision.'],['Quiz Mini-Game','A small browser quiz with score and instant feedback.'],['Personal Link Hub','One tidy page that gathers everything about me.']],
know:[['Did you know','CSS was first proposed in 1994 by Håkon Wium Lie.'],['UI tip','An 8px spacing grid keeps layouts tidy and consistent.'],['Fun fact','JavaScript was created in 1995 — reportedly in about ten days.'],['Remember','If it’s hard to read on a phone, it isn’t finished.']],
next:['React basics','Daily Flexbox/Grid','Accessibility','Git & GitHub']},
graphic:{focus:[['Typography','Pairing fonts, sizing and spacing so text carries the mood.'],['Colour theory','Building palettes with contrast, harmony and one strong accent.'],['Layout & hierarchy','Guiding the eye using grids, white space and scale.'],['Brand identity','Logos, packaging and visual language — like my Coco concept.']],
steps:[['Brief','Know the goal and audience.'],['Explore','Moodboard and quick sketches.'],['Compose','Layout, type, colour.'],['Export','Right format and size.']],
ideas:[['Study Poster Series','One topic per poster — formulas, diagrams, mnemonics.'],['Social Template Kit','Reusable post and story templates in one style.'],['Mini Brand Guide','Logo, colours and fonts for a concept brand on a single page.']],
know:[['Did you know','Body text should have roughly 4.5:1 contrast to stay readable (WCAG).'],['Rule of thirds','Place key subjects on grid intersections for balance.'],['Screens vs print','RGB is for screens, CMYK is for print.'],['Tip','Limit yourself to two typefaces — usually enough.']],
next:['Learn Figma','Logo basics','Grid systems','Personal brand kit']},
media:{focus:[['Photo editing','Light, colour and crop to make an image feel intentional.'],['Short-form video','Cuts, pacing and captions built for vertical screens.'],['Colour grading','Giving footage a consistent mood and look.'],['Storytelling','Hook → build → payoff, even in 15 seconds.']],
steps:[['Collect','Gather clips, photos, audio.'],['Cut','Trim to the strongest moments.'],['Grade','Colour and sound polish.'],['Export','Right ratio and quality.']],
ideas:[['30-Second Science','Quick visual explainers that make one concept stick.'],['Before / After Series','Short edits showing how an image transforms.'],['Local Stories','A photo story about everyday life around Sonbhadra.']],
know:[['Did you know','Cinema typically uses 24 frames per second.'],['Format tip','Reels, Shorts and Stories live in vertical 9:16.'],['Golden hour','Light just after sunrise and before sunset flatters almost everything.'],['Remember','Sound quality matters as much as the picture.']],
next:['DaVinci Resolve basics','Sound design','Colour grading','Motion text']},
science:{focus:[['Physics','Motion, energy, light and how forces shape everyday things.'],['Chemistry','Reactions, the periodic table and why matter behaves as it does.'],['Biology','Cells, body systems and how living things work.'],['Computer Technology','How computers and networks work — fuel for quizzes like TCS Rural IT.']],
steps:[['Curious','Ask “why does it happen?”'],['Concept','Learn the core idea.'],['Practice','Questions and quizzes.'],['Teach','Explain it back simply.']],
ideas:[['Visual Chapter Notes','Diagram-first revision notes for every chapter.'],['Science Quiz Mini-Site','Chapter-wise quizzes with instant scoring.'],['“Why Does It Happen?”','A short explainer series on everyday science.']],
know:[['Did you know','Sunlight takes about 8 minutes to reach Earth.'],['Biology','DNA is shaped like a double helix.'],['Computing','Computers store everything using just 0s and 1s.'],['Chemistry','Water boils at 100°C at sea level.']],
next:['Class 12 boards','More quizzes','Chapter diagrams','Coding basics']}
};
var QS=[['Which gas do plants absorb for photosynthesis?',['Oxygen','Carbon dioxide','Nitrogen'],1],['SI unit of force?',['Joule','Newton','Watt'],1],['pH of pure water at 25°C?',['5','7','9'],1],['Powerhouse of the cell?',['Nucleus','Ribosome','Mitochondria'],2],['The “brain” of a computer is the…',['CPU','Monitor','Keyboard'],0],['Approx. speed of light?',['3 × 10⁸ m/s','3 × 10⁶ m/s','3 × 10⁵ m/s'],0]];
var TOOLS={
ai:{t:'Prompt builder',h:'<label>Who should the AI be?</label><div class="opts" data-g="0"><button class="on">a patient teacher</button><button>a design mentor</button><button>a coding tutor</button></div><label>What should it do?</label><div class="opts" data-g="1"><button class="on">explain</button><button>summarise</button><button>quiz me on</button></div><label>How?</label><div class="opts" data-g="2"><button class="on">in simple words</button><button>step by step</button><button>with examples</button></div><div class="tout" id="tout"></div><button class="go2" id="cp">Copy prompt</button>'},
web:{t:'CSS playground',h:'<div class="demo"><i id="bx"></i></div><label>Corner radius</label><input type="range" id="r1" min="0" max="48" value="12"><label>Shadow blur</label><input type="range" id="r2" min="0" max="60" value="20"><div class="tout" id="tout"></div>'},
graphic:{t:'Palette shuffle',h:'<div class="pal" id="pal"></div><div class="tout" id="tout">Tap a colour to copy its hex.</div><button class="go2" id="sh">Shuffle palette</button>'},
media:{t:'Aspect ratios',h:'<div class="frm"><div id="fr"></div></div><div class="opts" id="ar"><button data-w="9" data-h="16" data-u="Reels · Shorts · Stories" class="on">9:16</button><button data-w="1" data-h="1" data-u="Square posts" >1:1</button><button data-w="4" data-h="5" data-u="Instagram feed portrait">4:5</button><button data-w="16" data-h="9" data-u="YouTube · Landscape">16:9</button></div>'},
science:{t:'Mini quiz',h:'<label id="qn"></label><div class="tout" id="tout"></div><div class="oq" id="oq"></div>'}
};

/* showcase blocks */
function xs(art,ico,tag,t,sub,d,note){return '<article class="xs"><div class="xa" style="background:'+art[0]+'">'+art[1]+'</div><div class="xi"><div class="xh"><span class="xic" style="background:'+ico[0]+'">'+ico[1]+'</span><span class="mono">'+tag+'</span></div><h3>'+t+'</h3><b>'+sub+'</b><p>'+d+'</p><small>● '+note+'</small></div></article>'}
function xph(bg,x){return '<div class="xph" style="background:'+bg+'"><i></i>'+x+'</div>'}
function xcl(label,items){var rs=[-2.5,1.8,-1.2,2.4,-2];return '<div class="xcl"><span class="mono">'+label+'</span><div class="xrow">'+items.map(function(p,i){return '<div class="xpp" style="--r:'+rs[i%5]+'deg;--i:'+i+'"><div style="background:'+p[0]+';color:'+p[1]+'">'+p[2]+'</div></div>'}).join('')+'</div></div>'}
var NOTE='<small class="xnote">Concept designs made for this portfolio — not client work.</small>';
var SHOW={
web:['Selected concepts',NOTE+'<div class="xsg">'+
 xs(['linear-gradient(135deg,#243b36,#111e1b)',xph('#f4eee5','<div style="font:italic 17px Georgia,serif;text-align:center">med<span style="color:#a65d3c">info</span>hub.</div><div style="height:1px;background:#c9bfb3;margin:9px 0"></div><div class="xtile" style="background:#dce6d8">BIOLOGY<strong>Learn visually.</strong></div><div class="xtile" style="background:#eee5d9">QUICK NOTES · CONCEPTS</div>')],['#243b36','m'],'WEB · EDUCATION','Medinfohub.ed','A study site idea for visual learning','Science notes as clean cards, with quick revision and a dark mode.','Concept mockup')+
 xs(['#d8c9b7','<div class="xbr"><div class="bar">forsneha.study</div><div class="bd"><small style="font:8px ui-monospace,monospace;letter-spacing:.1em">LEARN SOMETHING NEW</small><b style="display:block;font:800 36px/.9 system-ui;margin:10px 0">FOR<br><em style="font:italic 600 36px Georgia,serif;color:#a65d3c">SNEHA.</em></b><span style="font-size:10px">Thoughtful learning, made simple.</span></div></div>'],['#a65d3c','S'],'WEB · CONCEPT','For Sneha','An educational website concept','A friendly, focused learning page with a calm interface and clear hierarchy.','Concept mockup')+
 xs(['radial-gradient(circle at 50% 45%,#634d87,#171323 70%)',xph('transparent','<div style="display:grid;place-items:center;height:100%;color:#eee6ff;text-align:center"><div><div style="width:92px;height:92px;border:1px solid #d5b9ff88;border-radius:50%;margin:0 auto -62px;box-shadow:0 0 30px #b48cff55"></div><b style="font:800 24px/.85 system-ui;letter-spacing:-.06em;text-shadow:0 0 14px #bca2ff">BUBU<br><em style="font:italic 600 24px Georgia,serif;color:#d7b6ff">VERSE</em></b></div></div>')],['#634d87','B'],'3D WEB · EXPERIMENT','Bubuverse','An immersive 3D web experience','Scenes, motion and playful interaction, built with React and Three.js.','Experimental build')+'</div>'],
ai:['Concept preview',NOTE+'<div class="xsg">'+xs(['linear-gradient(135deg,#1F2E4D,#0f1830)',xph('#10172b','<b style="color:#fff;font-size:12px">Study Buddy</b><div class="xbub" style="background:#27365c;color:#dfe7ff">Explain photosynthesis in simple words.</div><div class="xbub" style="background:#f4eee5;margin-left:10%">Plants use sunlight, water and CO₂ to make food and release oxygen.</div><div class="xbub" style="background:#27365c;color:#dfe7ff">Now quiz me! ✦</div>')],['#1F2E4D','AI'],'AI · IDEA','AI Study Buddy','A chat helper for revision','Turns a chapter into simple explanations, flashcards and a short quiz.','Concept mockup')+'</div>'],
graphic:['Concept posters · scroll the line',NOTE+xcl('Brand concepts',[
 ['linear-gradient(125deg,#e4b84e,#f4d98a 55%,#b5c17b)','#3e331c','<small>FRESH IDEAS. FRESH TASTE.</small><b style="font:800 54px system-ui;letter-spacing:-.08em;margin:8px 0">COCO®</b><em style="font-size:14px">mango drink concept</em>'],
 ['#243b36','#e8eadf','<b style="font:italic 700 28px Georgia,serif">med<span style="color:#d18a65">info</span>hub.</b><small style="margin-top:14px">LEARN VISUALLY</small>'],
 ['#f1eae2','#1a1818','<b style="font:700 30px system-ui;letter-spacing:-.04em">Learning today.</b><em style="font:italic 600 30px Georgia,serif;color:#a65d3c">Innovating tomorrow.</em>'],
 ['#0C0B0B','#EDE8E3','<b style="font:italic 90px Georgia,serif;color:#d2b37a;line-height:.9">Ⅱ</b><small style="margin-top:10px;color:#d2b37a">TCS RURAL IT QUIZ 2026</small><span style="font-size:13px;margin-top:6px">State-level second place</span>'],
 ['#d8c9b7','#28221d','<b style="font:800 44px/.9 system-ui;letter-spacing:-.05em">FOR<br><em style="font:italic 600 44px Georgia,serif;color:#a65d3c">SNEHA.</em></b>']])],
media:['Grade lab',NOTE+'<div class="xba" id="ba"><img class="b" alt=""><img class="a" id="ba2" alt=""><span style="left:12px">B&amp;W</span><span style="right:12px">GRADED</span></div><input type="range" id="bs" min="0" max="100" value="50" style="width:100%;accent-color:#A9522B;margin:14px 0 6px"><div class="opts" id="lk"><button class="on" data-f="sepia(.45) saturate(1.4) contrast(1.05)">Warm</button><button data-f="sepia(.5) hue-rotate(165deg) saturate(2)">Cool</button><button data-f="grayscale(.6) contrast(.85) brightness(1.1)">Faded</button><button data-f="contrast(1.4) brightness(.95) saturate(1.3)">Punch</button></div>'],
science:['Study posters · scroll the line',NOTE+xcl('Visual notes',[
 ['#dce6d8','#1d2b22','<small>PHOTOSYNTHESIS</small><b style="font:700 19px/1.25 system-ui;margin:12px 0">6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂</b><span style="font-size:12px">needs light + chlorophyll</span>'],
 ['#1F2E4D','#eaf0ff','<small>OHM’S LAW</small><b style="font:800 52px system-ui;margin:10px 0">V = IR</b><span style="font-size:12px">voltage = current × resistance</span>'],
 ['#f4d98a','#3e331c','<small>THE pH SCALE</small><b style="font:800 64px system-ui;margin:6px 0">7</b><span style="font-size:12px">neutral · below acid · above base</span>'],
 ['#0C0B0B','#EDE8E3','<small>BINARY</small><b style="font:800 40px system-ui;margin:12px 0">1010₂ = 10</b><span style="font-size:12px">computers count in 0s and 1s</span>'],
 ['#f1eae2','#1a1818','<small>NEWTON’S 2ND LAW</small><b style="font:800 50px system-ui;margin:10px 0">F = ma</b><span style="font-size:12px">force = mass × acceleration</span>']])]
};

function autoRow(r){
  if(reduced)return;var pos=r.scrollLeft,dir=1,hold=0,hover=false;
  var stop=function(){hold=performance.now()+2500};
  ['pointerdown','touchstart','wheel'].forEach(function(ev){r.addEventListener(ev,stop,{passive:true})});
  r.addEventListener('scroll',function(){if(performance.now()>hold)return;pos=r.scrollLeft},{passive:true});
  r.addEventListener('mouseenter',function(){hover=true});r.addEventListener('mouseleave',function(){hover=false});
  (function f(){
    if(!document.body.contains(r))return;
    if(!hover&&!document.hidden&&performance.now()>hold){
      var max=r.scrollWidth-r.clientWidth;if(max>0){pos+=dir*.7;if(pos>=max){pos=max;dir=-1}if(pos<=0){pos=0;dir=1}r.scrollLeft=pos}
    }
    requestAnimationFrame(f);
  })();
}
function bindShow(k){
  Array.prototype.forEach.call($('rb').querySelectorAll('.xrow'),autoRow);
  if(k!=='media')return;
  var src=$('portrait').src;Array.prototype.forEach.call($('ba').querySelectorAll('img'),function(i){i.src=src});
  var a=$('ba2'),set=function(v){a.style.clipPath='inset(0 0 0 '+v+'%)'};set(50);
  a.style.filter=$('lk').querySelector('.on').dataset.f;
  $('bs').addEventListener('input',function(){set(this.value)});
  $('lk').addEventListener('click',function(e){var b=e.target;if(b.tagName!=='BUTTON')return;$('lk').querySelector('.on').classList.remove('on');b.classList.add('on');a.style.filter=b.dataset.f});
}
$('rmenu').addEventListener('click',async function(){$('back').click();await wait(reduced?0:900);menu(true)});
function sec(t,x){return '<div class="rs"><span class="mono">'+t+'</span>'+x+'</div>'}
function renderRoom(k){
  var r=ROOMS[k],T=TOOLS[k],i=0;
  $('rb').innerHTML=
   sec('00 — '+SHOW[k][0],SHOW[k][1])+
   sec('01 — What I’m exploring',r.focus.map(function(f,n){return '<div class="rl"><span>'+pad(n+1)+'</span><b>'+f[0]+'</b><small>'+f[1]+'</small></div>'}).join(''))+
   sec('02 — How I work','<div class="stp">'+r.steps.map(function(s,n){return '<div><span>STEP '+pad(n+1)+'</span><b>'+s[0]+'</b><small>'+s[1]+'</small></div>'}).join('')+'</div>')+
   sec('03 — Try it · '+T.t,'<div class="tool">'+T.h+'</div>')+
   sec('04 — Concepts I want to build','<small style="display:block;color:var(--ink-soft);margin-bottom:12px">Ideas on my list — not built yet.</small>'+r.ideas.map(function(d){return '<div class="idc"><span class="tag">IDEA</span><b>'+d[0]+'</b><small>'+d[1]+'</small></div>'}).join(''))+
   sec('05 — Tap to flip','<div class="fc">'+r.know.map(function(c){return '<button data-a="'+c[1]+'" data-q="'+c[0]+'"><small>'+c[0].toUpperCase()+'</small>Tap to reveal</button>'}).join('')+'</div>')+
   sec('06 — Next on my list','<div class="chips">'+r.next.map(function(n){return '<span>'+n+'</span>'}).join('')+'</div>');
  Array.prototype.forEach.call($('rb').querySelectorAll('.fc button'),function(b){b.addEventListener('click',function(){var f=b.classList.toggle('f');b.innerHTML='<small>'+b.dataset.q.toUpperCase()+'</small>'+(f?b.dataset.a:'Tap to reveal')})});
  bindShow(k);var tout=$('tout');
  if(k==='ai'){
    var g=Array.prototype.slice.call($('rb').querySelectorAll('.opts')),sel=function(n){return g[n].querySelector('.on').textContent};
    var up=function(){tout.textContent='Act as '+sel(0)+'. Please '+sel(1)+' [your topic] '+sel(2)+'. I’m a Class 12 student — keep it short and tell me if you’re unsure.'};
    g.forEach(function(o){o.addEventListener('click',function(e){if(e.target.tagName!=='BUTTON')return;o.querySelector('.on').classList.remove('on');e.target.classList.add('on');up()})});up();
    $('cp').addEventListener('click',function(){try{navigator.clipboard.writeText(tout.textContent)}catch(e){}$('cp').textContent='Copied ✓';setTimeout(function(){$('cp').textContent='Copy prompt'},1500)});
  }else if(k==='web'){
    var up2=function(){var a=$('r1').value,b=$('r2').value;$('bx').style.borderRadius=a+'px';$('bx').style.boxShadow='0 10px '+b+'px rgba(0,0,0,.35)';tout.textContent='border-radius:'+a+'px; box-shadow:0 10px '+b+'px rgba(0,0,0,.35);'};
    $('r1').addEventListener('input',up2);$('r2').addEventListener('input',up2);up2();
  }else if(k==='graphic'){
    var hex=function(h,s,l){s/=100;l/=100;var a=s*Math.min(l,1-l),f=function(n){var k2=(n+h/30)%12,c=l-a*Math.max(-1,Math.min(k2-3,9-k2,1));return Math.round(255*c).toString(16).padStart(2,'0')};return '#'+f(0)+f(8)+f(4)};
    var shuffle=function(){var h0=Math.random()*360;$('pal').innerHTML=[24,38,54,70,86].map(function(l,n){var c=hex((h0+n*14)%360,50+n*4,l);return '<button style="background:'+c+';color:'+(l>60?'#222':'#fff')+';text-shadow:none" data-c="'+c+'">'+c.toUpperCase()+'</button>'}).join('')};
    $('pal').addEventListener('click',function(e){var c=e.target.dataset.c;if(!c)return;try{navigator.clipboard.writeText(c)}catch(x){}tout.textContent='Copied '+c.toUpperCase()+' ✓'});
    $('sh').addEventListener('click',shuffle);shuffle();
  }else if(k==='media'){
    var set=function(b){var w=+b.dataset.w,hh=+b.dataset.h,fr=$('fr');fr.style.height='130px';fr.style.width=Math.round(130*w/hh)+'px';fr.textContent=b.textContent+' · '+b.dataset.u};
    $('ar').addEventListener('click',function(e){var b=e.target;if(b.tagName!=='BUTTON')return;$('ar').querySelector('.on').classList.remove('on');b.classList.add('on');set(b)});set($('ar').querySelector('.on'));
  }else{
    var q=0,sc=0;
    var show=function(){
      if(q>=QS.length){$('qn').textContent='Finished';tout.textContent='You scored '+sc+' / '+QS.length+(sc===QS.length?' — perfect!':' — nice, try again!');$('oq').innerHTML='<button id="rs2">Restart quiz</button>';$('rs2').addEventListener('click',function(){q=0;sc=0;show()});return}
      $('qn').textContent='Question '+(q+1)+' / '+QS.length+' · Score '+sc;tout.textContent=QS[q][0];
      $('oq').innerHTML=QS[q][1].map(function(o,n){return '<button data-n="'+n+'">'+o+'</button>'}).join('');
    };
    $('oq').addEventListener('click',function(e){var b=e.target;if(b.dataset.n===undefined||$('oq').dataset.lock)return;var ok=+b.dataset.n===QS[q][2];if(ok)sc++;b.classList.add(ok?'ok':'no');if(!ok)$('oq').children[QS[q][2]].classList.add('ok');$('oq').dataset.lock=1;setTimeout(function(){delete $('oq').dataset.lock;q++;show()},900)});
    show();
  }
}

/* sakura tree + falling petals */
var pet=$('pet'),pc=pet.getContext('2d'),PINKS=['#ffc2d4','#ffb0c8','#f8a1bd','#ffd6e2','#f58fb0'],TS=[],P=[],hero=document.querySelector('.hero'),tc=$('tree'),dpr2=Math.min(devicePixelRatio||1,2);
function mul(a){return function(){a|=0;a=a+0x6D2B79F5|0;var t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function drawTree(){
  var W=hero.clientWidth,H=hero.clientHeight;if(!W||!H)return;tc.width=W*dpr2;tc.height=H*dpr2;
  var x=tc.getContext('2d');x.setTransform(dpr2,0,0,dpr2,0,0);TS=[];
  var rnd=mul(11),bc=dark?'#4a342d':'#5b4338';
  function flower(fx,fy,s){x.save();x.translate(fx,fy);x.rotate(rnd()*6.28);x.fillStyle=PINKS[rnd()*PINKS.length|0];x.globalAlpha=.88;for(var q=0;q<5;q++){x.rotate(1.2566);x.beginPath();x.ellipse(0,-s*.75,s*.5,s*.8,0,0,6.2832);x.fill()}x.globalAlpha=1;x.fillStyle='#f6d36b';x.beginPath();x.arc(0,0,s*.22,0,6.2832);x.fill();x.restore()}
  function bloom(bx,by,k,sp){for(var i=0;i<k;i++){var fx=bx+(rnd()-.5)*sp,fy=by+(rnd()-.5)*sp;flower(fx,fy,3.5+rnd()*3.5);if(rnd()<.25)TS.push([fx,fy])}}
  function br(px,py,len,ang,w,d){
    var nx=px+Math.cos(ang)*len,ny=py+Math.sin(ang)*len;x.strokeStyle=bc;x.lineWidth=w;x.lineCap='round';x.beginPath();x.moveTo(px,py);
    x.quadraticCurveTo((px+nx)/2+(rnd()-.5)*len*.35,(py+ny)/2+(rnd()-.5)*len*.35,nx,ny);x.stroke();
    if(d<=3)bloom(nx,ny,d<=0?4:2,24);
    if(d<=0)return;
    var n=d>4?2:(rnd()<.4?3:2);
    for(var i=0;i<n;i++)br(nx,ny,len*(.7+rnd()*.12),ang+(i-(n-1)/2)*(.55+rnd()*.35)+(rnd()-.5)*.25,Math.max(w*.68,1.2),d-1);
  }
  var L=Math.min(H*.24,W*.5);br(W+6,H*.97,L,-Math.PI/2-.5,Math.max(9,W*.022),7);br(-8,-6,L*.55,1.05,6,5);
}
var rq=0;function redraw(){cancelAnimationFrame(rq);rq=requestAnimationFrame(drawTree)}
if(window.ResizeObserver)new ResizeObserver(redraw).observe(hero);else addEventListener('resize',redraw);
window.addEventListener('themechange',redraw);drawTree();
function sizePet(){pet.width=innerWidth*dpr2;pet.height=innerHeight*dpr2;pc.setTransform(dpr2,0,0,dpr2,0,0)}
sizePet();addEventListener('resize',sizePet);
function respawn(p,init){
  var r=hero.getBoundingClientRect(),t=(!init&&TS.length&&Math.random()<.55)?TS[Math.random()*TS.length|0]:null;
  if(t&&r.top+t[1]>-10&&r.top+t[1]<innerHeight*.85){p.x=t[0];p.y=r.top+t[1]}else{p.x=Math.random()*innerWidth;p.y=init?Math.random()*innerHeight:-20}
  p.vx=0;p.vy=0;p.bt=0;
}
function newP(){var p={c:PINKS[Math.random()*5|0],s:5+Math.random()*5,rot:Math.random()*6.28,vr:(Math.random()-.5)*.05,ph:Math.random()*6.28,fl:Math.random()*6.28,sp:.5+Math.random()*.7};respawn(p,true);return p}
function burst(bx,by){if(reduced)return;for(var i=0;i<26;i++){var p=newP();p.x=bx;p.y=by;p.vx=(Math.random()-.5)*8;p.vy=-2-Math.random()*5;p.bt=1;p.once=1;P.push(p)}}
if(!reduced){
  for(var pi=0;pi<(innerWidth<700?20:38);pi++)P.push(newP());
  var lt=performance.now(),T=0;
  (function fr(now){
    var dt=Math.min((now-lt)/16.67,3);lt=now;T+=dt*.016;
    if(!document.hidden){
      pc.clearRect(0,0,innerWidth,innerHeight);
      for(var i=P.length-1;i>=0;i--){
        var p=P[i];
        if(p.bt){p.vy+=.18*dt;p.vx*=.97;if(p.vy>p.sp)p.bt=0}
        p.y+=(p.bt?p.vy:p.sp)*dt;p.x+=((p.bt?p.vx:0)+Math.sin(T*50+p.ph)*.45+.18)*dt;p.rot+=p.vr*dt;p.fl+=.03*dt;
        if(p.y>innerHeight+20||p.x>innerWidth+30){if(p.once){P.splice(i,1);continue}respawn(p,false)}
        pc.save();pc.translate(p.x,p.y);pc.rotate(p.rot);pc.scale(Math.cos(p.fl),1);pc.globalAlpha=.88;pc.fillStyle=p.c;
        var s=p.s;pc.beginPath();pc.moveTo(0,-s);pc.bezierCurveTo(s*.9,-s*.6,s*.7,s*.7,0,s);pc.bezierCurveTo(-s*.7,s*.7,-s*.9,-s*.6,0,-s);pc.fill();pc.restore();
      }
    }
    requestAnimationFrame(fr);
  })(lt);
}
/* Hire me → compose mail */
var toast=document.createElement('div');toast.id='toast';document.body.appendChild(toast);var tt=0;
function mailBody(){return 'Hi Krishesh,\n\nI saw your portfolio and I’d like to talk about:\n\nName:\nProject / idea:\nTimeline:\n\nThanks!'}
var SUB='Hello Krishesh — let’s work together';
function mailUrl(){return 'mailto:'+CONFIG.email+'?subject='+encodeURIComponent(SUB)+'&body='+encodeURIComponent(mailBody())}
function gmailUrl(){return 'https://mail.google.com/mail/?view=cm&fs=1&to='+encodeURIComponent(CONFIG.email)+'&su='+encodeURIComponent(SUB)+'&body='+encodeURIComponent(mailBody())}
function showToast(){
  toast.innerHTML='Opening your mail app… <b>'+CONFIG.email+'</b> <button id="tcp">Copy</button><a href="'+gmailUrl()+'" target="_blank" rel="noopener">Gmail</a>';
  toast.classList.add('on');clearTimeout(tt);tt=setTimeout(function(){toast.classList.remove('on')},8000);
  $('tcp').addEventListener('click',function(){try{navigator.clipboard.writeText(CONFIG.email)}catch(e){}this.textContent='Copied ✓'});
}
function hireMail(e){
  if(e&&e.clientX!==undefined)burst(e.clientX,e.clientY);
  var a=document.createElement('a');a.href=mailUrl();a.target='_blank';a.rel='noopener';document.body.appendChild(a);a.click();a.remove();showToast();
}
$('mail').href=mailUrl();$('mail').addEventListener('click',function(e){burst(e.clientX,e.clientY);showToast()});
if('IntersectionObserver' in window){document.documentElement.classList.add('jsrv');var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.1});Array.prototype.forEach.call(document.querySelectorAll('.rv'),function(el){io.observe(el)})}
runLoader();
})();
